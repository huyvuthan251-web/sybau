# F-Linux 10.0 — build and release status

**Current artifact status: Developer Preview source tree. No ISO has been built or boot-tested in this workspace.**

| Area | Status | Evidence / limitation |
|---|---|---|
| Independent T2 target | Implemented | F-Linux target files and rootfs overlay; real T2 checkout/build not available in this workspace |
| F-Aero Xfce profile | Implemented | Theme, icons, wallpapers, Xfce defaults and desktop launchers; not viewed in a booted guest |
| Live account bootstrap | Implemented | `f-firstboot.service` creates a locked `flinux` account from `/etc/skel` only when the Live marker exists; mock-tested |
| LightDM autologin | Configured | Xfce autologin `flinux`; enabling happens in firstboot; not boot-tested against the exact T2 LightDM/PAM packages |
| Live sudo/polkit | Implemented | NOPASSWD sudo and active-local wheel polkit authorization are Live-only; both Live behavior and rule are removed by installer; installed sudo requires password |
| NetworkManager/Wi-Fi | Configured | NetworkManager uses wpa_supplicant; F-Network is an nmcli-based terminal app; bootstrap selects `linux-firmware`, `iw`, `wireless-regdb`, `shadow`, `upower` and `efibootmgr` only when recipes exist in the selected T2 snapshot |
| Desktop-ready marker | Implemented | `f-session-ready.service` waits for `xfce4-session` and emits a serial marker; unit/script static checks pass |
| F-Installer | Implemented as CLI/TUI preview | Supports UEFI/GPT or BIOS/GPT full-disk erase and rootfs copy; non-destructive plan tests pass; real install not tested |
| GRUB install | Integrated into F-Installer | Requires matching GRUB recipe selected in target; not verified in chroot or on physical firmware |
| F-Package / F-Store | Prototype | Local T2 archive front-end; no remote signed repository or dependency solver |
| F-Update | Placeholder | No signed update channel |
| F-Recovery | Basic read-only utilities | No automatic repair or rollback |
| QEMU BIOS/UEFI test harness | Implemented | Includes real serial marker wait and screenshot attempt; orchestration tested with mock QEMU only |
| Real ISO build | NOT DONE | Workspace cannot resolve GitHub/upstream network hosts; T2 checkout/source archives unavailable |
| QEMU BIOS boot | NOT DONE | No ISO to boot |
| QEMU UEFI boot | NOT DONE | No ISO to boot |
| Installer-to-disk + installed boot | NOT DONE | Requires real ISO and disposable VM disk |
| Physical hardware | NOT DONE | Wi-Fi/GPU/audio/Bluetooth/touchpad support is device-specific |

## Local checks performed in this workspace

- `tests/validate.sh`: PASS.
- `tests/test-firstboot.sh`: PASS (mocked account, locale and systemctl commands; not a boot test).
- `tests/test-network.sh`: PASS (mock nmcli status, Wi-Fi scan and connect flow).
- `tests/test-installer.sh`: PASS (help, input validation and non-destructive partition-plan output only; no disks changed).
- `tests/test-bootstrap-mock.sh`: PASS (mock T2 tree; optional package discovery and append-only config behavior).
- `tests/test-runtime.sh`: PASS (CLI and `f install --plan`; no real disk operations).
- `tests/test-qemu-wrapper.sh`: PASS (fake QEMU executable; no VM boot).
- `tests/test-boot-qemu-mock.sh`: PASS (fake QEMU executable simulates marker and screenshot response; no guest OS booted).
- `tests/test-aero-session.sh`: PASS.
- Shell syntax checks: PASS.
- Systemd unit parsing: static checks are included; dependency verification against a complete T2 rootfs remains pending.

## Release blockers

1. A real T2 source build and ISO creation.
2. QEMU boot to `F-LINUX-DESKTOP-READY` in BIOS and UEFI modes, retaining serial logs/screenshots.
3. Install from Live to a disposable VM disk in both supported firmware modes; reboot from installed disk and verify user login, sudo, networking and desktop.
4. Test NetworkManager with Ethernet and at least one Wi-Fi adapter, confirming firmware availability.
5. Test on representative real hardware before calling the image Stable.

Static/mock PASS results do not prove a zero-bug OS. Do not install this preview over a disk containing important data.
