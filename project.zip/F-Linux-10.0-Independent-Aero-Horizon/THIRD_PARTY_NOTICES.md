# Third-party notices

The target is built from upstream components using T2 SDE package recipes.
Each upstream package retains its own license and notices. The distribution
must ship the license texts and source-offer information required by the
licenses of the exact package revisions selected at build time.

T2 SDE is a separate upstream project; consult its repository and license.
Xfce is an upstream desktop environment; F-Aero styling does not imply that
Xfce is developed by F-Linux. Do not remove upstream copyright or license
notices from binaries or source archives.
