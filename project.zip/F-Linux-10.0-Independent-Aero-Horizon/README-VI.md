# F-Linux 10.0 — Aero Horizon

**Developer Preview của một Linux target độc lập được biên dịch từ source thông qua T2 SDE.** F-Linux không lấy Ubuntu/Debian root filesystem và không dùng APT/DPKG làm nền runtime. Ubuntu 24.04 chỉ là máy build host; các gói của hệ điều hành đích được T2 biên dịch từ recipe/source upstream.

> Đây chưa phải Stable 10.0. Chưa có ISO nào được build và boot kiểm chứng trong môi trường tạo source ZIP này. Không thể cam kết "không bug 100%" khi chưa hoàn thành full build, BIOS/UEFI boot, cài đặt và kiểm thử phần cứng.

## Tính năng của bản Preview

- Target T2 riêng `flinux`, kiến trúc x86-64.
- Xfce upstream được build từ source và tùy biến F-Aero: theme, icon, wallpaper, panel và session defaults. Đây là lớp tùy biến Xfce, chưa phải compositor do F-Linux tự viết.
- Live user `flinux` được tạo tự động ở lần boot Live đầu tiên, UID mặc định do `useradd` chọn, tự đăng nhập qua LightDM/Xfce. Không có mật khẩu mặc định dùng chung; password của tài khoản Live bị khóa.
- Trong Live image, nhóm `wheel` được dùng `sudo` không mật khẩu và polkit cho active local session. Đây chỉ là tiện ích của môi trường Live; installer loại bỏ marker/rule Live và chuyển sudo sang yêu cầu mật khẩu cho bản cài.
- `f-installer` cài F-Linux lên một ổ đĩa trống bằng cách sao chép rootfs Live, tạo GPT/ESP hoặc BIOS boot partition, tạo fstab/user/password và cài GRUB. **Hiện chỉ hỗ trợ xóa toàn bộ một ổ; không hỗ trợ dual-boot, giữ dữ liệu, LVM, RAID, mã hóa hay Secure Boot.**
- NetworkManager + `wpa_supplicant` là Wi-Fi backend; bootstrap chọn `linux-firmware`, `iw`, `wireless-regdb` nếu T2 snapshot có recipe tương ứng.
- `f-session-ready` phát dấu `F-LINUX-DESKTOP-READY` sau khi phát hiện tiến trình Xfce; dùng làm mốc cho QEMU boot test tự động.
- Bộ công cụ `f`, `f-pkg`, `f-store`, `f-update`, `f-recovery` là các frontend ban đầu. Repository có chữ ký, dependency solver và cập nhật tự động vẫn là công việc tương lai.

## Cấu hình build khuyến nghị

- Ubuntu 24.04 LTS x86_64 chỉ làm máy biên dịch.
- 8 threads CPU, RAM 16 GB, ổ đĩa trống tối thiểu 120 GB (nên có thêm nếu build sạch nhiều lần).
- Internet ổn định; lần đầu T2 cần clone source tree và tải nhiều source archives.
- Build cần quyền root ở một số bước chroot/ownership.

## Cách build trên Ubuntu 24.04

```bash
bash scripts/install-ubuntu-build-deps.sh
bash scripts/preflight.sh
bash scripts/bootstrap-t2.sh
```

Sau đó:

```bash
cd t2sde
sudo ./t2 config -cfg flinux
```

Chọn target `flinux`, architecture `x86-64`, image `live`. Bật `Custom package selection` để chọn recipe optional mà bootstrap tìm thấy, đặc biệt `networkmanager`, `wpa_supplicant`, `linux-firmware`, `rsync`, `parted`, `e2fsprogs`, `dosfstools`, `grub2`, `efibootmgr`, `shadow` và `upower`. Lưu cấu hình rồi quay về project root:

```bash
cd ..
sudo bash scripts/build-iso.sh
bash scripts/verify-iso.sh
```

## Tài khoản và desktop Live

- `flinux` là user Live được firstboot tạo tự động, LightDM auto-login vào Xfce.
- Không có password `flinux` dùng chung. Tài khoản Live được khóa mật khẩu; `sudo` chỉ được cấp NOPASSWD trong Live image.
- `f-firstboot.service` chỉ chạy khi `/etc/f-linux/live-session` tồn tại và `/etc` ghi được. Installer xóa marker và các unit/rule Live trước khi cài lên ổ đĩa.
- Nếu Xfce không lên, kiểm tra `journalctl -b -u f-firstboot -u lightdm -u f-session-ready` từ TTY.

## Mạng/Wi-Fi

- `NetworkManager.service` được enable ở lần boot Live đầu tiên.
- `wpa_supplicant` được chỉ định làm Wi-Fi backend của NetworkManager.
- `F-Network` là ứng dụng terminal riêng, mở bằng `f network`; có thể dùng `f net-status` hoặc `nmcli device status` để xem trạng thái.
- Firmware Wi-Fi phụ thuộc model card. Bootstrap thêm `linux-firmware` nếu recipe có trong T2 snapshot; recipe thiếu hoặc firmware upstream chưa hỗ trợ thì Wi-Fi có thể chưa hoạt động trên một số phần cứng.

## Cài lên ổ đĩa

Từ desktop Live, mở **Install F-Linux** hoặc chạy trong Terminal:

```bash
sudo f-installer --list-disks
sudo f-installer --plan --disk /dev/vda --mode uefi
sudo f-installer
```

`--plan` chỉ in kế hoạch và không thay đổi ổ. Khi cài thật, chọn đúng ổ rồi gõ chính xác `ERASE /dev/<disk>`. Mọi phân vùng và dữ liệu trên ổ được chọn sẽ bị xóa. Nên thử trong VM với disk ảo mới trước. Installer chưa được boot/install kiểm chứng trên máy thật trong workspace này.

## Kiểm tra tự động trước build

```bash
bash tests/validate.sh
bash tests/test-firstboot.sh
bash tests/test-network.sh
bash tests/test-installer.sh
bash tests/test-systemd-units.sh
bash tests/test-bootstrap-mock.sh
bash tests/test-runtime.sh
bash tests/test-qemu-wrapper.sh
bash tests/test-boot-qemu-mock.sh
bash tests/test-aero-session.sh
```

## QEMU boot test thật (sau khi có ISO)

Cài `qemu-system-x86`, `ovmf` và `qemu-utils`, sau đó:

```bash
bash scripts/test-boot-qemu.sh --bios
bash scripts/test-boot-qemu.sh --uefi
# Hoặc cả hai:
bash scripts/test-boot-matrix.sh
```

Test chờ dấu `F-LINUX-DESKTOP-READY` được ghi ra serial console. Log và screenshot nếu QEMU backend hỗ trợ được lưu ở `artifacts/boot-tests/{bios,uefi}/`. Đây là test boot thật, khác với `tests/test-qemu-wrapper.sh` vốn chỉ dùng QEMU giả để kiểm tra tham số.

## Hạn chế đã biết

- Chưa có kết quả build ISO thật/boot BIOS/UEFI trong môi trường tạo source này.
- Installer hiện là công cụ CLI/TUI trong terminal, không phải graphical installer; chỉ hỗ trợ xóa toàn bộ một disk và cần thử nghiệm trong VM trước.
- Secure Boot, mã hóa, dual-boot, RAID/LVM, Btrfs snapshot rollback chưa được hỗ trợ.
- Firmware thiết bị phụ thuộc recipe/kernel/upstream; chưa có ma trận test Wi-Fi/GPU/Bluetooth/touchpad trên phần cứng thật.
- `f-pkg` chưa có dependency solver; `f-store` chưa có repository online có chữ ký; `f-update` chưa bật cập nhật bảo mật.

Không gắn nhãn Stable cho đến khi full T2 build, checksum, BIOS/UEFI boot, disk install, installed-system boot, network/audio/input tests và release audit đều đạt.
