# Changelog — F-Linux 10.0 Aero Horizon

## Review fixes — 2026-11-03

- `tests/test-runtime.sh`: fixed a flaky failure (exit 141, SIGPIPE from `grep -q` under `pipefail`); outputs are captured before matching.
- Desktop launchers `f-installer.desktop` and `f-network.desktop` in `/etc/skel/Desktop` were not executable, so Xfce would treat them as untrusted; fixed and covered by `validate.sh`.
- `f-firstboot.sh`: services were only *enabled*, which does not start them in the current boot; they are now also queued with `systemctl start --no-block` so LightDM/NetworkManager come up in the first Live boot.
- `f-session-ready.service`: no longer delays `graphical.target` for up to 190 s and now orders after `lightdm.service`.
- `f-installer`: hostname and username are asked and validated before the disk is erased; `/dev/disk/by-*` symlinks are resolved to the real device; the password prompt retries; the installed system gets its own motd; added `--version`; removed an unused variable.
- `f-network`: a failed Wi-Fi action (e.g. wrong password) no longer terminates the menu and closes the terminal.
- `/etc/motd` no longer advertises a non-existent Live password.
- `run-qemu.sh`: also looks for `OVMF_CODE_4M.fd` (Ubuntu 24.04 layout), like the boot-test script.
- CI: `shellcheck -S warning -x` (the previous default failed on informational notes).

## 10.0 Developer Preview — 2026-11-03

- Added a Live marker and idempotent firstboot setup for the `flinux` desktop user.
- Removed the shared default Live password; the Live user is password-locked and LightDM handles autologin.
- Restricted passwordless wheel sudo and the local polkit convenience rule to the Live image; the disk installer removes both Live-only settings and changes installed sudo to password-required.
- Added systemd enablement for LightDM, NetworkManager, Bluetooth and graphical target during Live firstboot.
- Added explicit NetworkManager Wi-Fi backend configuration using wpa_supplicant, a desktop network applet and optional T2 recipes for firmware/wireless tools.
- Added F-Installer CLI/TUI preview with non-destructive UEFI/BIOS partition plans, full-disk confirmation, rootfs copy, user/password setup, Live-state cleanup and GRUB integration.
- Added a desktop-ready service that emits `F-LINUX-DESKTOP-READY` to the serial console after Xfce is detected.
- Added QEMU BIOS/UEFI boot test scripts with serial-log wait and optional PPM screenshot capture.
- Added mocked test coverage for firstboot, installer plan generation and QEMU boot-test orchestration.
- Documented that real T2 build, ISO creation, VM boots and installer boots are still release blockers.

This release is a source Developer Preview, not a boot-verified Stable ISO.

## Live desktop / installer hardening

- Added a Live-only `flinux` account created from `/etc/skel`, locked password, LightDM Xfce autologin, and Live-only wheel sudo/polkit policy.
- Added a full-disk CLI installer with UEFI and BIOS partition layouts, user password setup, Live privilege removal, and GRUB integration. It remains a destructive preview and is not yet install/boot validated.
- Added NetworkManager + wpa_supplicant configuration and the `F-Network` nmcli-based terminal UI; removed the unprovided `nm-applet` autostart.
- Added real BIOS/UEFI QEMU boot-test scripts and mock-only harness tests. No real guest boot has been performed because an ISO has not been built in this workspace.
