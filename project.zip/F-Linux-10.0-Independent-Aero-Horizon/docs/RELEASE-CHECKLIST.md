# F-Linux release gate

A release must not be marked stable until all applicable checks are recorded
with machine model, firmware mode, test date, T2 commit, kernel version and
ISO SHA-256.

- [ ] T2 target configured from a clean checkout.
- [ ] All required source downloads pass checksums.
- [ ] `t2 build-target -cfg flinux` completes with no unapproved package errors.
- [ ] ISO creation completes and El Torito boot catalog is present.
- [ ] QEMU BIOS boot reaches the F-Linux desktop.
- [ ] QEMU UEFI boot reaches the F-Linux desktop.
- [ ] VirtualBox BIOS/UEFI boot.
- [ ] VMware boot.
- [ ] Physical Intel/AMD desktop boot.
- [ ] Laptop Wi-Fi, Bluetooth, audio, webcam, suspend and touchpad.
- [ ] Live firstboot creates the locked `flinux` account and LightDM autologin reaches Xfce.
- [ ] NetworkManager Ethernet and Wi-Fi tests pass; `wpa_supplicant` and appropriate firmware are present.
- [ ] Installer UEFI install to a disposable VM disk completes and the installed system reboots.
- [ ] Installer BIOS install to a disposable VM disk completes and the installed system reboots.
- [ ] Installed system has no Live marker, no Live autologin, no Live polkit rule and password-required sudo.
- [ ] Package archive install/remove tested; dependency limitations documented.
- [ ] Update/recovery path tested before claiming production readiness.
- [ ] Licenses, firmware redistribution and user-supplied media permissions audited.
- [ ] ISO checksum and release notes published.
