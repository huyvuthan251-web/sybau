# Security notes

F-Linux 10.0 is a developer preview, not a security-certified operating system.
Do not use it as the sole OS for sensitive work.

- The Live session auto-logs into a password-locked `flinux` account. The Live
  image grants NOPASSWD sudo to `wheel` for installation and diagnostics; this
  privilege exists only in the Live environment. The disk installer removes the
  Live marker, firstboot wants-link and Live polkit rule, then changes sudo to
  password-required before creating/activating the installed user.
- The installer destroys all partitions on the explicitly confirmed target disk.
  It has no dual-boot preservation, manual partitioning, encryption, RAID/LVM,
  Secure Boot or data recovery. Test only on a disposable virtual disk.
- The F-Package frontend installs local T2 archives with administrative
  privileges. Only use archives built for the exact target and from sources you
  trust. T2 `bize` does not solve dependencies.
- No remote package repository is configured. Do not add an unsigned repository.
- `f-update` intentionally performs no package changes in this preview.
- `f-recovery status` is read-only; `f-recovery shell` merely opens a shell.
- Firewall defaults, AppArmor policy, Secure Boot signing, initramfs recovery,
  vulnerability response and update rollback require additional release work.

- The Live polkit rule grants active, local `wheel` sessions `polkit.Result.YES`; this is intentionally broad for the ephemeral demo environment and is removed by the disk installer. Never copy this rule into the installed system.
