# F-Linux architecture

## Distribution model

F-Linux is a source-built Linux distribution target. T2 SDE is the build
framework/recipe collection, not a Debian or Ubuntu base image. The target
root filesystem is assembled from T2-built packages and the F-Linux overlay
in `target/flinux/rootfs/`. The build host (for example Ubuntu 24.04) is only
a build environment and is not copied into the target filesystem.

## Layers

- **Linux kernel:** upstream Linux kernel built by T2, with an F-Linux x86-64
  configuration fragment for UEFI, storage, network, audio, graphics and VM drivers.
- **Base userland:** GNU toolchain, libc, init, core utilities, libraries and
  filesystem/network packages selected by T2's generic desktop template.
- **F-Aero Desktop:** first release uses the upstream Xfce components built
  from source by T2, with F-Linux-owned wallpaper, GTK theme, icon theme,
  default translucent-blue bottom panel, app launchers and session preferences.
  The T2 bootstrap selects Xfce recipes when those recipes are present, rather
  than assuming that a generic desktop template always selects Xfce. This is
  not yet a new compositor or a wholly original desktop environment.
- **F command tools:** `f`, `f-pkg`, `f-store`, `f-update`, `f-recovery`,
  read-only hardware/network/security diagnostics, session styling and startup
  audio. F-Store is a local archive catalogue only;
  no signed network repository or dependency solver is enabled yet.
- **Image:** T2 creates a bootable Live ISO. A separate graphical installer
  and verified install-to-disk workflow are not claimed in this preview.

## Package model

The first preview uses T2's `bize` local archive tool via the `f-pkg` frontend.
T2 documents that `bize` handles tar archives but does not solve dependencies.
Therefore F-Package currently supports local package archives only; it does
not yet provide a network repository, signature trust chain, dependency
resolver, transactional rollback or unattended upgrades.

## Portability

The first target is x86_64. The kernel fragment enables common virtio, VMware,
VirtualBox, e1000, PCnet, AHCI, NVMe and common audio/input drivers as modules
where possible. Actual hardware support depends on the selected kernel version,
firmware availability and testing on each device.
