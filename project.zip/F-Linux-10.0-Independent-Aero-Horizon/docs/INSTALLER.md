# F-Linux Live disk installer — preview

The Live image contains `/usr/bin/f-installer`. It is a terminal-driven installer that copies the running F-Linux root filesystem onto one selected disk, creates GPT partitions, configures fstab/hostname/machine-id and a user password, disables Live autologin/privileges, enables system services and installs GRUB.

## Non-destructive plan

```bash
f-installer --plan --disk /dev/vda --mode uefi
f-installer --plan --disk /dev/nvme0n1 --mode bios
```

No disk writes occur in `--plan` mode.

## Real install

1. Boot the F-Linux Live ISO.
2. Inspect disks using `sudo f-installer --list-disks`.
3. Run `sudo f-installer`.
4. Select a whole disk and boot mode.
5. Read the warning and type the exact confirmation shown by the installer.
6. Provide computer name, username and a new password.
7. Remove the ISO and boot from the installed disk.

**Destructive:** all partitions and data on the selected disk are erased. The preview has no dual-boot detection/preservation, no manual partitioning, no LVM/RAID/encryption, no Secure Boot support and no graphical partition editor. Always test on a disposable VM disk first. No claim of successful installation is made until a QEMU install-and-reboot test has passed.
