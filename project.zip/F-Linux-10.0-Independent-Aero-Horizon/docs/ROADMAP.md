# F-Linux roadmap

## 10.0 Aero Horizon — Developer Preview
- Independent x86-64 T2 source-built target.
- XFCE source-built desktop with F-Aero theme, default glass-blue panel, wallpaper, icons and startup sound option.
- F command center with hardware/network/security read-only diagnostics, local F-Store catalogue, package archive frontend and recovery tools.
- Live image target only; no stable-release claim.

## 10.1 Install and hardware hardening
- Complete clean T2 build and verify BIOS/UEFI Live ISO.
- Add a tested graphical installer, account creation, disk partitioning safeguards and rollback plan.
- Test VirtualBox, VMware, QEMU and selected physical desktops/laptops.
- Validate Wi-Fi, Bluetooth, GPU, audio, suspend and firmware policy.

## 10.2 Package ecosystem
- F-Package metadata format and repository index.
- Signed repository metadata, Ed25519 trust roots and key rotation.
- Dependency graph, conflicts, transaction log and rollback.
- Package build pipeline and reproducible-build attestations.

## 10.3 F-Desktop evolution
- Original F-Panel and F-Launcher.
- Dedicated F-Settings and accessibility review.
- Wayland session and compositor evaluation.

## 11.0 Stable foundation
- CI builds for supported target configurations.
- Security response process, kernel updates and release signing.
- Full hardware compatibility statement, upgrade and recovery tests.
