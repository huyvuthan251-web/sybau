# Build, login, install and test guide

## Build host

Recommended build host: Ubuntu 24.04 x86_64 VM, 8 CPU threads, 16 GiB RAM and at least 120 GiB free disk. The build host is not the F-Linux base system. T2 builds the target packages from source recipes. Internet access is required for cloning T2 and fetching source archives.

## Build steps

1. Extract the source archive into a writable directory.
2. Run `bash scripts/install-ubuntu-build-deps.sh`.
3. Run `bash scripts/preflight.sh`.
4. Run `bash scripts/bootstrap-t2.sh` as a normal user.
5. Run `cd t2sde && sudo ./t2 config -cfg flinux`.
6. Select target `flinux`, architecture `x86-64`, image `live`.
7. Enable Custom package selection so the recipe-backed optional dependencies discovered by bootstrap are selected (network-manager, wireless, firmware, installer and desktop tools).
8. Save configuration, return to project root and run `sudo bash scripts/build-iso.sh`.
9. Verify ISO with `bash scripts/verify-iso.sh`.

Bootstrap appends missing recipe-backed packages to `config/flinux/pkgsel` without deleting existing user rules. T2 package selection and recipe availability can change between snapshots; inspect the generated file and T2's config summary before starting the long build.

## Live login sequence

`/etc/f-linux/live-session` marks the volatile Live image. `f-firstboot.service` runs during boot, creates `flinux` via `/etc/skel`, locks the account password (no shared default password), adds it to `wheel` and enables `NetworkManager`, `lightdm` and Bluetooth if their units exist. LightDM autologins to the Xfce session. Live sudoers grants NOPASSWD only to `wheel`; the installer removes that Live-only rule and writes a password-required sudoers rule on the installed system.

The service intentionally enables LightDM for the normal graphical target rather than trying to start it directly from sysinit. `f-session-ready.service` waits for the actual `xfce4-session` process and emits `F-LINUX-DESKTOP-READY` to the serial console; QEMU tests use that marker.

## Network and Wi-Fi

NetworkManager is configured to use `wpa_supplicant`. The bootstrap adds `wpa_supplicant`, `linux-firmware`, `wireless-regdb`, `iw`, `shadow`, `upower` and `efibootmgr` only when recipes are present in the checked-out T2 source tree. The `F-Network` terminal utility uses `nmcli` and does not assume a separate `nm-applet` package. A missing firmware recipe or unsupported device firmware can prevent Wi-Fi on particular hardware. Check the final T2 package selection before building.

## Disk installer

The Live desktop includes `Install F-Linux`, which invokes `/usr/bin/f-installer` in a terminal via sudo. The installer is CLI/TUI, not a graphical partition editor. It supports:

- UEFI: GPT, 512 MiB FAT32 EFI System Partition, ext4 root partition, GRUB x86_64-efi.
- Legacy BIOS: GPT, 2 MiB BIOS boot partition, ext4 root partition, GRUB i386-pc.
- Rootfs copy from the Live system, fresh machine-id, fstab, new user/password, LightDM without autologin and password-required sudo.

The installer erases every partition on the selected whole disk. It does not support dual boot, manual partition layouts, RAID, LVM, encryption, Secure Boot or preserving existing data. Run `f-installer --plan --disk /dev/vda --mode uefi` to view a non-destructive plan. Test only on a disposable VM disk until the installer has passed repeated QEMU install-and-reboot tests.

## Static and mock tests

```bash
bash tests/validate.sh
bash tests/test-firstboot.sh
bash tests/test-installer.sh
bash tests/test-systemd-units.sh
bash tests/test-bootstrap-mock.sh
bash tests/test-runtime.sh
bash tests/test-qemu-wrapper.sh
bash tests/test-boot-qemu-mock.sh
bash tests/test-aero-session.sh
```

The QEMU wrapper mock does not boot an operating system. It only validates command-line arguments.

## Real BIOS/UEFI QEMU boot test

After a real ISO exists, install QEMU/OVMF, then run:

```bash
bash scripts/test-boot-qemu.sh --bios
bash scripts/test-boot-qemu.sh --uefi
# Sequential matrix:
bash scripts/test-boot-matrix.sh
```

The test launches QEMU headlessly with serial logging, waits for the desktop-ready marker and asks the HMP monitor to write a VGA screenshot. Logs and screenshots (when supported by the QEMU display backend) are written under `artifacts/boot-tests/`. A timeout or missing marker is a test failure. The screenshot is best-effort and may not be produced by every headless backend.

## Release gate

Do not call this Stable until a full source build succeeds, the ISO checksum is produced, both BIOS and UEFI QEMU boot tests pass, the installer has installed to a disposable disk and booted from it, Wi-Fi/network tests pass, and representative physical hardware has been checked.
