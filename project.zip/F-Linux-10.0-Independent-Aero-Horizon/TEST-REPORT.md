# F-Linux 10.0 — validation report

Executed in the artifact workspace on 2026-11-03 after the Live-login, installer and QEMU-test-harness changes.

| Test | Result | Scope |
|---|---|---|
| `tests/validate.sh` | PASS | Bash syntax/headers, T2 target layout, required Live/installer/network files, Live polkit authorization, XML/SVG, desktop entries, release identity, assets and no Debian/Ubuntu package-root dependency |
| `tests/test-firstboot.sh` | PASS | Mocked creation of password-locked Live user, wheel membership, sudoers mode, locale, service enablement and idempotent second run |
| `tests/test-network.sh` | PASS | F-Network status, Wi-Fi scan and connect menu with mocked nmcli; no live Wi-Fi hardware tested |
| `tests/test-installer.sh` | PASS | Help, BIOS/UEFI partition-plan output, non-destructive `--plan`, invalid device/mode rejection; no real disk modified |
| `tests/test-systemd-units.sh` | PASS | `systemd-analyze verify` parses the firstboot and graphical readiness units using minimal dependency stubs |
| `tests/test-bootstrap-mock.sh` | PASS | Mock T2 tree, desktop template discovery, append-only recipe selection for network/installer packages and preservation of custom rules |
| `tests/test-runtime.sh` | PASS | CLI help/version/info, hardware/security diagnostics, store-list/path-traversal checks, package cancellation and `f install --plan` |
| `tests/test-qemu-wrapper.sh` | PASS | Existing interactive QEMU wrapper arguments using a fake QEMU executable; no VM boot |
| `tests/test-boot-qemu-mock.sh` | PASS | Boot-test orchestration, serial ready-marker wait, monitor screenshot request and BIOS/UEFI option handling using a fake QEMU program; no guest boot |
| `tests/test-aero-session.sh` | PASS | F-Aero defaults initialize while preserving user-selected theme and wallpaper |
| Shell syntax | PASS | `bash -n` over project scripts and target command-line tools |
| Real T2 build / ISO | NOT RUN | No upstream T2/source download; DNS/network in this workspace could not resolve GitHub |
| Real QEMU BIOS/UEFI boot | NOT RUN | No real ISO exists to boot |
| Real disk install and installed-system boot | NOT RUN | Must be tested against a disposable VM disk after ISO creation |
| Physical hardware | NOT RUN | No physical PC/Wi-Fi/GPU/audio/Bluetooth test performed |

A PASS in a mocked test only proves the tested script path/contract. It does not establish that upstream packages compile, that the ISO boots, or that hardware is supported. F-Linux remains a Developer Preview.
