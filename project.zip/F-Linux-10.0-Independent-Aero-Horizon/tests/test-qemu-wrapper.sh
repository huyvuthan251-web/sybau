#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin"
printf 'fake-iso' > "$TMP/test.iso"
cat > "$TMP/bin/qemu-system-x86_64" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$@" > "$QEMU_ARGS_CAPTURE"
STUB
chmod +x "$TMP/bin/qemu-system-x86_64"
QEMU_ARGS_CAPTURE="$TMP/args-bios" PATH="$TMP/bin:$PATH" \
  bash "$ROOT/scripts/run-qemu.sh" "$TMP/test.iso" --ram 8192 --cpus 2
grep -qx '8192' "$TMP/args-bios"
grep -qx '2' "$TMP/args-bios"
grep -qx "$TMP/test.iso" "$TMP/args-bios"
: > "$TMP/OVMF_CODE.fd"
QEMU_ARGS_CAPTURE="$TMP/args-uefi" OVMF_CODE="$TMP/OVMF_CODE.fd" PATH="$TMP/bin:$PATH" \
  bash "$ROOT/scripts/run-qemu.sh" "$TMP/test.iso" --uefi
grep -qx -- '-bios' "$TMP/args-uefi"
grep -qx "$TMP/OVMF_CODE.fd" "$TMP/args-uefi"
echo '[PASS] QEMU wrapper argument parsing (mocked launcher; no VM boot performed)'
