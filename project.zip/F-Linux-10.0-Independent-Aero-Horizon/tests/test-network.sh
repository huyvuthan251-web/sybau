#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin"
cat > "$TMP/bin/nmcli" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$*" >> "$NMCLI_LOG"
case "$*" in
  'general status') echo 'connected (site only)' ;;
  'device status') echo 'DEVICE TYPE STATE CONNECTION' ;;
  'radio wifi on'|'radio wifi off') : ;;
  'device wifi rescan') : ;;
  '-f IN-USE,SSID,SECURITY,SIGNAL,CHAN device wifi list') echo 'IN-USE SSID SECURITY SIGNAL CHAN' ;;
  '-t -f DEVICE,TYPE device status') echo 'wlan0:wifi' ;;
esac
STUB
chmod +x "$TMP/bin/nmcli"
export NMCLI_LOG="$TMP/nmcli.log"
printf '1\n0\n' | PATH="$TMP/bin:$PATH" bash "$ROOT/target/flinux/rootfs/usr/bin/f-network" > "$TMP/status"
grep -q 'Connection status' "$TMP/status"
grep -q '^general status$' "$NMCLI_LOG"
: > "$NMCLI_LOG"
printf '2\n0\n' | PATH="$TMP/bin:$PATH" bash "$ROOT/target/flinux/rootfs/usr/bin/f-network" > "$TMP/scan"
grep -q '^device wifi rescan$' "$NMCLI_LOG"
grep -q 'device wifi list' "$NMCLI_LOG"
: > "$NMCLI_LOG"
printf '3\nTestNetwork\n\n0\n' | PATH="$TMP/bin:$PATH" bash "$ROOT/target/flinux/rootfs/usr/bin/f-network" > "$TMP/connect"
grep -Fq -- '--ask device wifi connect TestNetwork' "$NMCLI_LOG"
printf '[PASS] F-Network status, scan and interactive Wi-Fi connect flows (mock nmcli)\n'
