#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ROOT/target/flinux/rootfs/usr/bin"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

"$BIN/f" version | grep -qx 'F-Linux 10.0 (Aero Horizon)'
"$BIN/f" help > "$TMP/help.out"
grep -q 'f store' "$TMP/help.out"
grep -q 'f hardware' "$TMP/help.out"
grep -q 'f security' "$TMP/help.out"
grep -q 'f install' "$TMP/help.out"
PATH="$BIN:$PATH" "$BIN/f" install --plan --disk /dev/vda --mode uefi > "$TMP/plan.out"
grep -q 'NO DISK CHANGES' "$TMP/plan.out"
"$BIN/f" info > "$TMP/info.out"
grep -q 'Architecture:' "$TMP/info.out"
"$BIN/f" hardware > "$TMP/hardware.out"
grep -q 'F-Linux hardware overview' "$TMP/hardware.out"
"$BIN/f" security > "$TMP/security.out"
grep -q 'F-Linux security status' "$TMP/security.out"
"$BIN/f-pkg" help > "$TMP/pkg.out"; grep -q 'local package interface' "$TMP/pkg.out"
"$BIN/f-store" help > "$TMP/store.out"; grep -q 'local package archive catalogue' "$TMP/store.out"
"$BIN/f-recovery" help > "$TMP/rec.out"; grep -q 'read-only' "$TMP/rec.out"
"$BIN/f-update" > "$TMP/upd.out"; grep -q 'does not yet ship a signed' "$TMP/upd.out"
mkdir -p "$TMP/store" "$TMP/bin"
printf 'fixture' > "$TMP/store/example-1.tar.zst"
cat > "$TMP/bin/bize" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$@" > "$BIZE_CAPTURE"
STUB
chmod +x "$TMP/bin/bize"
FLINUX_PACKAGE_STORE="$TMP/store" "$BIN/f-store" list > "$TMP/list.out"; grep -qx 'example-1.tar.zst' "$TMP/list.out"
FLINUX_PACKAGE_STORE="$TMP/missing" "$BIN/f-store" list > "$TMP/list2.out"; grep -q 'Package store is empty' "$TMP/list2.out"
if FLINUX_PACKAGE_STORE="$TMP/store" "$BIN/f-store" install ../outside.tar.zst >/dev/null 2>&1; then
  echo '[FAIL] f-store accepted a path traversal attempt.' >&2
  exit 1
fi
# The local archive manager must stop on an unconfirmed operation.
printf 'NO\n' | BIZE_CAPTURE="$TMP/bize-args" PATH="$TMP/bin:$PATH" \
  "$BIN/f-pkg" install "$TMP/store/example-1.tar.zst" > "$TMP/cancel.out"
grep -q 'Cancelled.' "$TMP/cancel.out"
[[ ! -e "$TMP/bize-args" ]] || { echo '[FAIL] f-pkg ran bize without confirmation.' >&2; exit 1; }
echo '[PASS] F-Linux runtime CLI, package confirmation and F-Store smoke tests'
