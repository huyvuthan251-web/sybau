#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }

[[ "$(cat "$ROOT/VERSION")" == '10.0' ]] || fail 'VERSION must be 10.0'
while IFS= read -r -d '' file; do
  first_line="$(head -n1 "$file" || true)"
  if [[ "$first_line" == *bash* || "$first_line" == *'/sh'* ]]; then
    [[ "$first_line" == '#!'* ]] || fail "invalid shebang: $file"
    bash -n "$file" || fail "shell syntax: $file"
  fi
done < <(find "$ROOT/scripts" "$ROOT/tests" -type f -name '*.sh' -print0; find "$ROOT/target/flinux/rootfs/usr/bin" -maxdepth 1 -type f -print0)
pass 'shell syntax and executable script headers'

[[ -f "$ROOT/target/flinux/config.in" ]] || fail 'missing target config.in'
[[ -f "$ROOT/target/flinux/build.sh" ]] || fail 'missing target build.sh'
grep -q 'target/generic/build.sh' "$ROOT/target/flinux/build.sh" || fail 'target must use T2 generic build flow'
[[ -s "$ROOT/target/flinux/linux.conf" ]] || fail 'kernel config fragment missing'
[[ -f "$ROOT/target/flinux/pkgsel" ]] || fail 'target/flinux/pkgsel (T2 package selection file) is missing'
grep -q '^include target/generic/pkgsel/.*desktop' "$ROOT/target/flinux/pkgsel" || fail 'target/flinux/pkgsel must include the generic desktop template'
grep -q "SDECFGSET_IMAGE='live'" "$ROOT/target/flinux/config.in" || fail "T2 image type must be 'live'" 
pass 'T2 target skeleton'

for command in f f-pkg f-store f-update f-recovery f-aero-session f-startup-sound f-polkit-agent f-installer f-session-ready f-network; do
  file="$ROOT/target/flinux/rootfs/usr/bin/$command"
  [[ -x "$file" ]] || fail "missing executable: $command"
  [[ "$(head -n1 "$file")" == '#!/usr/bin/env bash' ]] || fail "bad first-line shebang: $command"
done
for rel in usr/lib/systemd/f-firstboot.sh usr/lib/systemd/system/f-firstboot.service \
  usr/lib/systemd/system/sysinit.target.wants/f-firstboot.service \
  usr/lib/systemd/system/f-session-ready.service usr/lib/systemd/system/graphical.target.wants/f-session-ready.service \
  etc/f-linux/live-session etc/systemd/system/default.target \
  etc/lightdm/lightdm.conf.d/50-f-linux.conf etc/NetworkManager/NetworkManager.conf \
  etc/sudoers.d/10-f-linux-wheel etc/polkit-1/rules.d/50-f-linux-admin.rules \
  etc/polkit-1/rules.d/49-f-linux-live-wheel.rules etc/profile.d/90-f-linux-locale.sh \
  etc/profile.d/91-f-linux-input.sh etc/xdg/autostart/f-ibus.desktop \
  etc/xdg/autostart/f-polkit-agent.desktop \
  usr/share/applications/f-installer.desktop usr/share/applications/f-network.desktop \
  etc/skel/Desktop/f-network.desktop; do
  [[ -s "$ROOT/target/flinux/rootfs/$rel" ]] || fail "missing login/locale file: $rel"
done
[[ -x "$ROOT/target/flinux/rootfs/usr/lib/systemd/f-firstboot.sh" ]] || fail 'f-firstboot.sh must be executable'
head -n1 "$ROOT/target/flinux/rootfs/usr/lib/systemd/system/sysinit.target.wants/f-firstboot.service" | grep -q '^#!ln -sf' || fail 'sysinit wants entry must be a T2 "#!ln -sf" directive'
head -n1 "$ROOT/target/flinux/rootfs/usr/lib/systemd/system/graphical.target.wants/f-session-ready.service" | grep -q '^#!ln -sf' || fail 'graphical target readiness link must be a T2 symlink directive'
head -n1 "$ROOT/target/flinux/rootfs/etc/systemd/system/default.target" | grep -q '^#!ln -sf' || fail 'default.target must point to graphical.target'
[[ -x "$ROOT/target/flinux/rootfs/usr/bin/f-installer" ]] || fail 'f-installer must be executable'
[[ -x "$ROOT/scripts/test-boot-qemu.sh" && -x "$ROOT/scripts/test-boot-matrix.sh" ]] || fail 'QEMU boot-test scripts missing'
bash -n "$ROOT/target/flinux/rootfs/usr/lib/systemd/f-firstboot.sh" || fail 'f-firstboot.sh syntax'
bash -n "$ROOT/target/flinux/rootfs/usr/bin/f-installer" || fail 'f-installer syntax'
bash -n "$ROOT/target/flinux/rootfs/usr/bin/f-session-ready" || fail 'f-session-ready syntax'
grep -q '^ConditionPathExists=/etc/f-linux/live-session$' "$ROOT/target/flinux/rootfs/usr/lib/systemd/system/f-firstboot.service" || fail 'firstboot must be guarded by the Live marker'
grep -q '^autologin-user=flinux$' "$ROOT/target/flinux/rootfs/etc/lightdm/lightdm.conf.d/50-f-linux.conf" || fail 'LightDM Live autologin user missing'
grep -q '^wifi.backend=wpa_supplicant$' "$ROOT/target/flinux/rootfs/etc/NetworkManager/NetworkManager.conf" || fail 'NetworkManager Wi-Fi backend missing'
grep -q 'F-LINUX-DESKTOP-READY' "$ROOT/target/flinux/rootfs/usr/bin/f-session-ready" || fail 'desktop readiness marker missing'
grep -q '^%wheel .*NOPASSWD' "$ROOT/target/flinux/rootfs/etc/sudoers.d/10-f-linux-wheel" || fail 'Live sudoers must be passwordless only in Live image'
grep -q 'polkit.Result.YES' "$ROOT/target/flinux/rootfs/etc/polkit-1/rules.d/49-f-linux-live-wheel.rules" || fail 'Live polkit rule must authorize active local wheel session'
grep -q 'f-installer' "$ROOT/target/flinux/rootfs/usr/bin/f" || fail 'f-installer command integration missing'
grep -q 'f-network' "$ROOT/target/flinux/rootfs/usr/bin/f" || fail 'F-Network command integration missing'
[[ ! -e "$ROOT/target/flinux/rootfs/etc/xdg/autostart/f-network-applet.desktop" ]] || fail 'invalid nm-applet autostart must not be installed'
grep -q '^ID=flinux$' "$ROOT/target/flinux/rootfs/etc/os-release" || fail 'wrong os-release ID'
pass 'runtime utilities and release identity'

python3 - "$ROOT" <<'PYCODE'
from pathlib import Path
import sys, xml.etree.ElementTree as ET
root = Path(sys.argv[1])
for p in root.rglob('*.svg'):
    ET.parse(p)
for p in (root / 'target/flinux/rootfs').rglob('*.xml'):
    ET.parse(p)
# Default desktop profiles must be valid XML and point only to the F-Linux theme.
panel = ET.parse(root / 'target/flinux/rootfs/etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml')
assert panel.getroot().attrib.get('name') == 'xfce4-panel'
settings = ET.parse(root / 'target/flinux/rootfs/etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml')
assert settings.getroot().attrib.get('name') == 'xsettings'

for p in (root / 'target/flinux/rootfs').rglob('*.desktop'):
    rows = {}
    in_group = False
    for raw in p.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if line == '[Desktop Entry]': in_group = True; continue
        if in_group and '=' in line and not line.startswith('#'):
            k, v = line.split('=', 1); rows[k] = v
    assert rows.get('Type') == 'Application', f'{p}: Type missing'
    assert rows.get('Name'), f'{p}: Name missing'
    assert rows.get('Exec'), f'{p}: Exec missing'
for line in (root / 'target/flinux/rootfs/etc/os-release').read_text().splitlines():
    assert not line or ('=' in line and not line.startswith(' ')), line
# Catch the common generator regression where a stray slash precedes a shebang.
for p in (root / 'target/flinux/rootfs/usr/bin').iterdir():
    if p.is_file():
        assert p.read_text(encoding='utf-8').startswith('#!'), f'{p}: missing shebang'
print('[PASS] SVG, XML, desktop entries, os-release and runtime script checks')
PYCODE

for asset in "$ROOT/assets/f-linux-icon.png" "$ROOT/assets/f-linux-wordmark.png" "$ROOT/assets/aero-horizon-wallpaper.jpg" "$ROOT/assets/aqua-city-wallpaper.jpg" "$ROOT/assets/user-startup-sound.mp3"; do
  [[ -s "$asset" ]] || fail "missing asset: $asset"
done
pass 'brand assets present'

if grep -RniE 'apt-get|apt install|dpkg|debootstrap|live-build|--distribution trixie|deb\.debian\.org|archive\.ubuntu\.com' "$ROOT/target/flinux"; then
  fail 'Debian/Ubuntu package-root dependency found inside F-Linux target'
fi
pass 'no Debian/Ubuntu package-root dependency in target'

# Regression checks for bugs found in review.
for launcher in "$ROOT"/target/flinux/rootfs/etc/skel/Desktop/*.desktop; do
  [[ -x "$launcher" ]] || fail "Desktop launcher is not executable (Xfce shows it as untrusted): $launcher"
done
if grep -qi 'password "flinux"' "$ROOT/target/flinux/rootfs/etc/motd"; then
  fail 'motd advertises a Live password that does not exist (the Live account is password-locked)'
fi
grep -q 'start --no-block' "$ROOT/target/flinux/rootfs/usr/lib/systemd/f-firstboot.sh" \
  || fail 'f-firstboot must queue enabled services for the current boot (enable alone only takes effect next boot)'
pass 'regression checks (launcher modes, motd, firstboot service start)'

echo 'Static validation passed. This does NOT prove that T2 can build every upstream package or that the ISO boots on all hardware.'
