#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
if ! command -v systemd-analyze >/dev/null 2>&1; then
  echo '[SKIP] systemd-analyze is not installed on this test host.'
  exit 0
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
UNIT_DIR="$TMP/usr/lib/systemd/system"
mkdir -p "$UNIT_DIR" "$TMP/usr/lib/systemd" "$TMP/usr/bin"
cp "$ROOT/target/flinux/rootfs/usr/lib/systemd/system/f-firstboot.service" "$UNIT_DIR/"
cp "$ROOT/target/flinux/rootfs/usr/lib/systemd/system/f-session-ready.service" "$UNIT_DIR/"
cp "$ROOT/target/flinux/rootfs/usr/lib/systemd/f-firstboot.sh" "$TMP/usr/lib/systemd/"
cp "$ROOT/target/flinux/rootfs/usr/bin/f-session-ready" "$TMP/usr/bin/"
chmod 0755 "$TMP/usr/lib/systemd/f-firstboot.sh" "$TMP/usr/bin/f-session-ready"
for unit in local-fs.target sysinit.target graphical.target shutdown.target; do
  printf '[Unit]\nDescription=Test stub %s\n' "$unit" > "$UNIT_DIR/$unit"
done
for unit in systemd-sysusers.service systemd-tmpfiles-setup.service display-manager.service; do
  cat > "$UNIT_DIR/$unit" <<'SERVICE'
[Unit]
Description=Test stub service
[Service]
Type=oneshot
ExecStart=/usr/bin/true
SERVICE
done
# systemd-analyze validates unit syntax and ordering against these minimal
# dependency stubs; it does not emulate a real boot or T2's package filesystem.
cp /usr/bin/true "$TMP/usr/bin/true"
systemd-analyze --root="$TMP" verify \
  /usr/lib/systemd/system/f-firstboot.service \
  /usr/lib/systemd/system/f-session-ready.service
echo '[PASS] systemd unit syntax and ordering parse (minimal dependency root)'
