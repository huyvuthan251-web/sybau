#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin" "$TMP/usr/share/backgrounds/f-linux"
: > "$TMP/usr/share/backgrounds/f-linux/Aero-Horizon.jpg"
cat > "$TMP/bin/xfconf-query" <<'STUB'
#!/usr/bin/env bash
set -Eeuo pipefail
STATE="${XFCONF_STATE:?}"
channel=''
property=''
create=0
type=''
value=''
list=0
while (($#)); do
  case "$1" in
    -c) channel="$2"; shift 2 ;;
    -p) property="$2"; shift 2 ;;
    -l) list=1; shift ;;
    --create) create=1; shift ;;
    -t) type="$2"; shift 2 ;;
    -s) value="$2"; shift 2 ;;
    *) shift ;;
  esac
done
if (( list )); then
  awk -F'|' -v c="$channel" '$1==c {print $2}' "$STATE"
  exit 0
fi
if grep -Fqx -- "$channel|$property|" "$STATE" 2>/dev/null; then :; fi
row="$(awk -F'|' -v c="$channel" -v p="$property" '$1==c && $2==p {print; exit}' "$STATE")"
if [[ -n "$row" ]]; then
  printf '%s\n' "${row#*|}" | cut -d'|' -f2-
  exit 0
fi
if (( create )); then
  printf '%s|%s|%s|%s\n' "$channel" "$property" "$value" "$type" >> "$STATE"
  exit 0
fi
exit 1
STUB
chmod +x "$TMP/bin/xfconf-query"
cat > "$TMP/state" <<'STATE'
xsettings|/Net/ThemeName|User-Selected|String
xfce4-desktop|/backdrop/screen0/monitor0/workspace0/last-image|/home/test/wallpaper.jpg|String
STATE
# The session script uses a fixed system wallpaper path; provide the readable asset there.
mkdir -p "$TMP/backgrounds/f-linux"
: > "$TMP/backgrounds/f-linux/Aero-Horizon.jpg"
# Run with a mock xfconf tool. Existing user's theme and wallpaper must not be overwritten.
XFCONF_STATE="$TMP/state" FLINUX_WALLPAPER="$TMP/usr/share/backgrounds/f-linux/Aero-Horizon.jpg" PATH="$TMP/bin:$PATH" \
  "$ROOT/target/flinux/rootfs/usr/bin/f-aero-session"
grep -qx 'xsettings|/Net/ThemeName|User-Selected|String' "$TMP/state"
grep -qx 'xfce4-desktop|/backdrop/screen0/monitor0/workspace0/last-image|/home/test/wallpaper.jpg|String' "$TMP/state"
grep -qx 'xsettings|/Net/IconThemeName|F-Aero|string' "$TMP/state"
grep -qx 'xsettings|/Xft/Hinting|1|int' "$TMP/state"
grep -qx 'xsettings|/Xft/Antialias|1|int' "$TMP/state"
echo '[PASS] F-Aero session sets missing defaults and preserves existing user preferences'
