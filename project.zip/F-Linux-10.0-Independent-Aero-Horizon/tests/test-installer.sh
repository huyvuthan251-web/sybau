#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALLER="$ROOT/target/flinux/rootfs/usr/bin/f-installer"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
bash "$INSTALLER" --help > "$TMP/help"
grep -q 'erases the selected whole disk' "$TMP/help"
bash "$INSTALLER" --plan --disk /dev/vda --mode uefi > "$TMP/uefi"
grep -q 'NO DISK CHANGES' "$TMP/uefi"
grep -q 'EFI System Partition' "$TMP/uefi"
grep -q 'ext4 root filesystem' "$TMP/uefi"
bash "$INSTALLER" --plan --disk /dev/nvme0n1 --mode bios > "$TMP/bios"
grep -q 'BIOS boot partition' "$TMP/bios"
grep -q 'remaining space, ext4 root filesystem' "$TMP/bios"
if bash "$INSTALLER" --plan --disk /etc/passwd --mode uefi >/dev/null 2>&1; then
  echo '[FAIL] installer accepted a non-/dev disk path' >&2
  exit 1
fi
if bash "$INSTALLER" --plan --disk /dev/vda --mode invalid >/dev/null 2>&1; then
  echo '[FAIL] installer accepted an invalid firmware mode' >&2
  exit 1
fi
echo '[PASS] installer help, UEFI/BIOS plans and invalid input rejection (non-destructive)'
