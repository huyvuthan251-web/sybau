#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPT="$ROOT/target/flinux/rootfs/usr/lib/systemd/f-firstboot.sh"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin" "$TMP/etc/sudoers.d" "$TMP/etc/f-linux" "$TMP/units"
cp "$ROOT/target/flinux/rootfs/etc/sudoers.d/10-f-linux-wheel" "$TMP/etc/sudoers.d/"
chmod 0644 "$TMP/etc/sudoers.d/10-f-linux-wheel"
touch "$TMP/etc/f-linux/live-session"
for unit in lightdm.service NetworkManager.service bluetooth.service upower.service; do : > "$TMP/units/$unit"; done
stub() { printf '#!/usr/bin/env bash\n%s\n' "$2" > "$TMP/bin/$1"; chmod +x "$TMP/bin/$1"; }
stub getent '
case "$1:$2" in
  group:wheel) [[ -e "$TMP_STATE/group-wheel" ]] ;;
  group:*) exit 0 ;;
  passwd:flinux) [[ -e "$TMP_STATE/user-flinux" ]] ;;
  *) exit 2 ;;
esac'
stub groupadd ': > "$TMP_STATE/group-wheel"'
stub useradd 'printf "%s\n" "$@" > "$TMP_STATE/useradd-args"; : > "$TMP_STATE/user-flinux"'
stub passwd 'printf "%s\n" "$@" >> "$TMP_STATE/passwd-args"'
stub usermod 'printf "%s\n" "$@" >> "$TMP_STATE/usermod-args"'
stub localedef 'printf "%s\n" "$@" > "$TMP_STATE/localedef-args"'
stub locale 'exit 0'
stub runuser 'exit 0'
stub systemctl 'printf "%s\n" "$*" >> "$TMP_STATE/systemctl-args"'
export TMP_STATE="$TMP"
PATH="$TMP/bin:$PATH" FLINUX_ETC="$TMP/etc" FLINUX_LIVE_MARKER="$TMP/etc/f-linux/live-session" \
  FLINUX_UNIT_DIRS="$TMP/units" bash "$SCRIPT" > "$TMP/firstboot.log"
grep -qx 'flinux' "$TMP/useradd-args"
grep -q -- '-m' "$TMP/useradd-args"
grep -q -- '-G' "$TMP/useradd-args"
grep -q '^ -l\|^-l' "$TMP/passwd-args"
grep -q 'enable lightdm.service' "$TMP/systemctl-args"
grep -q 'enable NetworkManager.service' "$TMP/systemctl-args"
grep -q 'set-default graphical.target' "$TMP/systemctl-args"
[[ "$(stat -c %a "$TMP/etc/sudoers.d/10-f-linux-wheel")" == 440 ]]
! grep -q 'flinux:flinux\|chpasswd' "$SCRIPT"
# A second boot must not recreate the user; service enablement remains idempotent.
rm -f "$TMP/useradd-args"
PATH="$TMP/bin:$PATH" FLINUX_ETC="$TMP/etc" FLINUX_LIVE_MARKER="$TMP/etc/f-linux/live-session" \
  FLINUX_UNIT_DIRS="$TMP/units" bash "$SCRIPT" > /dev/null
[[ ! -e "$TMP/useradd-args" ]]
# The unit must be ordered before sysinit and guarded by the Live marker.
grep -q 'ConditionPathExists=/etc/f-linux/live-session' "$ROOT/target/flinux/rootfs/usr/lib/systemd/system/f-firstboot.service"
echo '[PASS] Live firstboot creates a locked user, configures sudo/polkit context, locale and services'
