#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
T2="$TMP/t2"
PROJECT="$TMP/project"
mkdir -p "$T2/target/generic/pkgsel" "$T2/package/media/mpv" "$T2/package/www/firefox" \
  "$T2/package/xfce4/xfce4-panel" "$T2/package/xfce4/xfce4-session" \
  "$T2/package/xfce4/thunar" "$T2/package/network/networkmanager" \
  "$T2/package/network/wpa_supplicant" "$T2/package/base/rsync" \
  "$T2/package/base/parted" "$T2/package/base/e2fsprogs" \
  "$T2/package/base/dosfstools" "$T2/package/base/shadow" \
  "$T2/package/base/upower" "$T2/package/boot/grub2" "$T2/package/boot/efibootmgr" "$PROJECT/target"
cp -a "$ROOT/target/flinux" "$PROJECT/target/flinux"
cat > "$T2/t2" <<'STUB'
#!/usr/bin/env bash
exit 0
STUB
chmod +x "$T2/t2"
cat > "$T2/target/generic/pkgsel/50-base-desktop.in" <<'TPL'
# TITLE: Base X.org and (Xfce) Desktop
include target/generic/pkgsel/20-base.in
X xorg-server
TPL
cat > "$T2/target/generic/pkgsel/20-base.in" <<'TPL'
# TITLE: Base
X bash
TPL
: > "$T2/package/media/mpv/mpv.desc"
: > "$T2/package/www/firefox/firefox.desc"
: > "$T2/package/xfce4/xfce4-panel/xfce4-panel.desc"
: > "$T2/package/xfce4/xfce4-session/xfce4-session.desc"
: > "$T2/package/xfce4/thunar/thunar.desc"
: > "$T2/package/network/networkmanager/networkmanager.desc"
: > "$T2/package/network/wpa_supplicant/wpa_supplicant.desc"
: > "$T2/package/base/rsync/rsync.desc"
: > "$T2/package/base/parted/parted.desc"
: > "$T2/package/base/e2fsprogs/e2fsprogs.desc"
: > "$T2/package/base/dosfstools/dosfstools.desc"
: > "$T2/package/base/shadow/shadow.desc"
: > "$T2/package/base/upower/upower.desc"
: > "$T2/package/boot/grub2/grub2.desc"
: > "$T2/package/boot/efibootmgr/efibootmgr.desc"
git -C "$T2" init -q
git -C "$T2" config user.email test@example.invalid
git -C "$T2" config user.name 'F-Linux Test'
git -C "$T2" add .
git -C "$T2" commit -qm 'mock T2 checkout'
FLINUX_PROJECT_DIR="$PROJECT" T2_DIR="$T2" "$ROOT/scripts/bootstrap-t2.sh"
test -f "$T2/target/flinux/.flinux-managed"
test -f "$T2/target/flinux/pkgsel"
grep -qx 'include target/generic/pkgsel/50-base-desktop.in' "$T2/target/flinux/pkgsel"
test -f "$T2/config/flinux/pkgsel"
grep -qx 'X mpv' "$T2/config/flinux/pkgsel"
grep -qx 'X firefox' "$T2/config/flinux/pkgsel"
grep -qx 'X xfce4-panel' "$T2/config/flinux/pkgsel"
grep -qx 'X xfce4-session' "$T2/config/flinux/pkgsel"
grep -qx 'X thunar' "$T2/config/flinux/pkgsel"
grep -qx 'X networkmanager' "$T2/config/flinux/pkgsel"
grep -qx 'X wpa_supplicant' "$T2/config/flinux/pkgsel"
grep -qx 'X rsync' "$T2/config/flinux/pkgsel"
grep -qx 'X parted' "$T2/config/flinux/pkgsel"
# Verify bootstrap never resets or cleans the upstream checkout.
printf 'local-change\n' > "$T2/LOCAL_TEST_CHANGE"
# Simulate the user adding an extra package rule; rerunning must preserve it.
printf 'X user-custom-package\n' >> "$T2/config/flinux/pkgsel"
FLINUX_PROJECT_DIR="$PROJECT" T2_DIR="$T2" "$ROOT/scripts/bootstrap-t2.sh"
grep -qx 'local-change' "$T2/LOCAL_TEST_CHANGE"
grep -qx 'X user-custom-package' "$T2/config/flinux/pkgsel"
echo '[PASS] T2 bootstrap integration, managed target refresh, and local-change preservation'
