#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP" "$ROOT/artifacts/boot-tests"' EXIT
mkdir -p "$TMP/bin"
printf 'mock iso\n' > "$TMP/test.iso"
cat > "$TMP/bin/qemu-system-x86_64" <<'PY'
#!/usr/bin/env python3
import os, socket, sys, threading, time
args = sys.argv[1:]
def value_after(flag):
    i = args.index(flag)
    return args[i + 1]
serial = value_after('-serial').removeprefix('file:')
monitor = value_after('-monitor').removeprefix('unix:').split(',')[0]
os.makedirs(os.path.dirname(serial), exist_ok=True)
os.makedirs(os.path.dirname(monitor), exist_ok=True)
server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
server.bind(monitor)
server.listen(1)
stop = threading.Event()
def write_marker():
    time.sleep(1)
    with open(serial, 'w', encoding='utf-8') as f:
        f.write('F-LINUX-BOOT: F-LINUX-DESKTOP-READY\r\n')
threading.Thread(target=write_marker, daemon=True).start()
while not stop.is_set():
    server.settimeout(1)
    try:
        conn, _ = server.accept()
    except socket.timeout:
        continue
    with conn:
        conn.sendall(b'(qemu) ')
        while True:
            data = conn.recv(4096)
            if not data:
                break
            command = data.decode('utf-8', errors='ignore').strip()
            if command.startswith('screendump '):
                path = command.split(' ', 1)[1]
                with open(path, 'wb') as f:
                    f.write(b'P6\n1 1\n255\n\xff\x00\xff')
                conn.sendall(b'(qemu) ')
            elif command == 'quit':
                stop.set()
                break
server.close()
try:
    os.unlink(monitor)
except FileNotFoundError:
    pass
PY
chmod +x "$TMP/bin/qemu-system-x86_64"
PATH="$TMP/bin:$PATH" bash "$ROOT/scripts/test-boot-qemu.sh" --iso "$TMP/test.iso" --bios --timeout 30
: > "$TMP/ovmf-code.fd"
PATH="$TMP/bin:$PATH" OVMF_CODE="$TMP/ovmf-code.fd" bash "$ROOT/scripts/test-boot-qemu.sh" --iso "$TMP/test.iso" --uefi --timeout 30
echo '[PASS] QEMU real-boot harness orchestration (mock QEMU; no guest was booted)'
