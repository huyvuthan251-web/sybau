# F-Linux 10.0 — Aero Horizon

F-Linux is a source-built Linux distribution target using T2 SDE as its build
framework and upstream source recipe collection. It is not an Ubuntu or Debian
binary-root remix. The build host is separate from the target root filesystem.

**Status: Developer Preview.** This source archive is not a verified release
image. Full upstream package builds, ISO boot, installation and hardware tests
remain required.

See `README-VI.md` for build instructions in Vietnamese and `docs/` for
architecture, testing, security and release requirements.
