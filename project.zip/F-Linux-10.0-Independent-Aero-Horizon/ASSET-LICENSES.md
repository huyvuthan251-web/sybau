# Asset and media notes

- `assets/f-linux-icon.png` and `assets/f-linux-wordmark.png`: generated for
  this F-Linux project; retain project attribution in source packages.
- `assets/aero-horizon-wallpaper.jpg` and `assets/aqua-city-wallpaper.jpg`:
  project visuals generated for the F-Linux design.
- `assets/user-startup-sound.mp3`: supplied by the user in this conversation.
  The user's distribution/license rights are not independently verified.
  It is included in this private development bundle at the user's request.
  Do not publish an ISO containing this file unless the user confirms they
  own the rights or the file's license permits redistribution. Remove the
  asset and its rootfs copy for public builds if permission is unclear.
