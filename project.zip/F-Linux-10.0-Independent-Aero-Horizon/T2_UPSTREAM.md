# T2 SDE upstream references

- Project repository: https://github.com/rxrbln/t2sde
- Quick build: https://t2linux.com/documentation/buildintro.html
- New target guide: https://www.t2linux.com/handbook/html/t2.target.from-scratch.html
- Target rootfs overlay: https://t2linux.com/handbook/html/t2.target.overlay.html
- Target development: https://t2linux.com/handbook/html/t2.target.html
- T2 package list: https://www.t2linux.com/packages/

F-Linux uses the documented target extension points (`config.in`, `pkgsel`,
`build.sh`, `linux.conf`, `rootfs/`) and generic source-build flow. The exact
upstream T2 commit is recorded in `T2-LOCK.txt` after bootstrap.
