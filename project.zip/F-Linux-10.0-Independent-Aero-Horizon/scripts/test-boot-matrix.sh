#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ISO="$PROJECT_DIR/dist/F-Linux-10.0-Aero-Horizon-amd64.iso"
[[ -s "$ISO" ]] || { echo "ISO not found: $ISO" >&2; exit 1; }
"$PROJECT_DIR/scripts/test-boot-qemu.sh" --iso "$ISO" --bios
"$PROJECT_DIR/scripts/test-boot-qemu.sh" --iso "$ISO" --uefi
echo '[PASS] F-Linux BIOS and UEFI QEMU boot matrix completed'
