#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ISO="${1:-}"
[[ -n "$ISO" ]] || ISO="$(find "$PROJECT_DIR/dist" -maxdepth 1 -type f -name '*.iso' -print -quit 2>/dev/null || true)"
[[ -n "$ISO" && -s "$ISO" ]] || { echo 'Usage: scripts/verify-iso.sh [path/to/image.iso]' >&2; exit 2; }
command -v file >/dev/null 2>&1 || { echo 'file command is required.' >&2; exit 127; }
file "$ISO"
if command -v xorriso >/dev/null 2>&1; then
  echo '--- El Torito boot catalogue ---'
  xorriso -indev "$ISO" -report_el_torito plain 2>&1 | sed -n '1,120p'
else
  echo 'xorriso unavailable; skipping boot-catalogue inspection.' >&2
fi
if [[ -f "$ISO.sha256" ]]; then
  (cd "$(dirname "$ISO")" && sha256sum -c "$(basename "$ISO").sha256")
elif [[ -f "$ISO.sha" ]]; then
  echo 'T2 checksum file found:'; cat "$ISO.sha"
else
  echo 'No adjacent checksum found; generate one before sharing.' >&2
fi
