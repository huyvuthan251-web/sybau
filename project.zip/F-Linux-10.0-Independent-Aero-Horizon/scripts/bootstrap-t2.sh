#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="${FLINUX_PROJECT_DIR:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)}"
T2_DIR="${T2_DIR:-$PROJECT_DIR/t2sde}"
T2_REPO="${T2_REPO:-https://github.com/rxrbln/t2sde.git}"
fail() { echo "[FAIL] $*" >&2; exit 1; }

command -v git >/dev/null 2>&1 || fail 'git is missing; run scripts/install-ubuntu-build-deps.sh.'

if [[ ! -d "$T2_DIR/.git" ]]; then
  [[ ! -e "$T2_DIR" ]] || fail "Refusing to overwrite non-git directory: $T2_DIR"
  echo "Cloning T2 SDE: $T2_REPO"
  git clone --depth 1 "$T2_REPO" "$T2_DIR"
else
  # Never reset, clean, or fetch over a user's existing source tree.
  echo "Using existing T2 checkout without modifying its Git state: $T2_DIR"
fi
[[ -x "$T2_DIR/t2" ]] || fail 'T2 checkout has no executable top-level t2 script.'
[[ -d "$T2_DIR/target/generic/pkgsel" ]] || fail 'T2 target/generic/pkgsel directory is missing; upstream layout changed.'

# target/flinux/pkgsel includes T2's generic desktop template; make sure it exists.
# Upstream titles it "Base X.org and (Xfce) Desktop" (older snapshots: "Base-desktop").
template="$T2_DIR/target/generic/pkgsel/50-base-desktop.in"
if [[ ! -f "$template" ]]; then
  template=''
  while IFS= read -r candidate; do
    if grep -Eiq '^#[[:space:]]*TITLE:.*desktop' "$candidate"; then
      template="$candidate"; break
    fi
  done < <(find "$T2_DIR/target/generic/pkgsel" -maxdepth 1 -type f -name '*.in' | sort)
fi
[[ -n "$template" ]] || fail 'T2 desktop package selection template not found.'
# Point target/flinux/pkgsel at the template that actually exists in this snapshot.
rel_template="${template#"$T2_DIR"/}"

# Install the F-Linux target without touching unrelated T2 targets.
target="$T2_DIR/target/flinux"
if [[ -e "$target/.flinux-managed" ]]; then
  rm -rf -- "$target"
elif [[ -e "$target" ]]; then
  fail "Refusing to replace existing unmanaged T2 target: $target"
fi
mkdir -p "$target"
cp -a "$PROJECT_DIR/target/flinux/." "$target/"
sed -i "s|^include target/generic/pkgsel/.*desktop.*\.in\$|include $rel_template|" "$target/pkgsel"
printf 'Managed by F-Linux project at %s\n' "$PROJECT_DIR" > "$target/.flinux-managed"

# T2's current package selection rules are stored in config/<name>/pkgsel,
# while reusable preselection templates live in target/generic/pkgsel/*.in.
config_dir="$T2_DIR/config/flinux"
rules_file="$config_dir/pkgsel"
# Preserve any existing user selections. Add only recipe-backed F-Linux
# dependencies which are not already selected; never reset the user's file.
mkdir -p "$config_dir"
touch "$rules_file"
optional=(
  # Explicit Xfce desktop stack.
  libxfce4util xfconf libxfce4ui libxfce4windowing libexo garcon
  xfce4-panel xfce4-session xfce4-settings xfwm4 xfdesktop thunar
  thunar-volman tumbler xfce4-appfinder xfce4-terminal xfce4-power-manager
  xfce4-notifyd mousepad ristretto
  # Network, wireless firmware and common device controls.
  networkmanager wpa_supplicant linux-firmware wireless-regdb iw
  bluez blueman shadow upower
  # Live installer and boot tools.
  rsync parted e2fsprogs dosfstools grub2 efibootmgr
  # Desktop/audio/browser packages which are optional in some T2 snapshots.
  xorg-server xorg-xinit mesa pipewire alsa-utils mpv firefox
  lightdm lightdm-gtk-greeter sudo polkit polkit-gnome
)
added=0
for pkg in "${optional[@]}"; do
  if find "$T2_DIR/package" -type f -path "*/$pkg/$pkg.desc" -print -quit 2>/dev/null | grep -q .; then
    if ! grep -Fqx "X $pkg" "$rules_file"; then
      printf 'X %s\n' "$pkg" >> "$rules_file"
      added=$((added + 1))
    fi
  else
    echo "[INFO] Optional package recipe not found in this T2 snapshot; skipping: $pkg"
  fi
done

REV="$(git -C "$T2_DIR" rev-parse HEAD)"
BRANCH="$(git -C "$T2_DIR" branch --show-current 2>/dev/null || true)"
{
  printf 'T2 repository: %s\n' "$T2_REPO"
  printf 'T2 commit: %s\n' "$REV"
  printf 'T2 branch: %s\n' "${BRANCH:-detached}"
  printf 'Desktop template used by target/flinux/pkgsel: %s\n' "$rel_template"
  printf 'F-Linux target: target/flinux\n'
  printf 'Optional custom package rules: %s\n' "${rules_file}"
} > "$PROJECT_DIR/T2-LOCK.txt"

echo
echo 'F-Linux target installed into T2 without resetting or modifying the upstream Git checkout.'
echo "T2 commit: $REV"
echo "Desktop template detected: $template"
if [[ -s "$rules_file" ]]; then
  echo 'Optional package rules prepared:'
  cat "$rules_file"
else
  echo 'No optional package recipes were found; the desktop template in target/flinux/pkgsel will be used as-is.'
fi
echo
echo 'Next: open T2 configuration as root:'
echo "  cd '$T2_DIR'"
echo '  sudo ./t2 config -cfg flinux'
echo 'Choose Target flinux, Architecture x86-64 (image type: live), enable Custom package selection so network/firmware/installer recipes found by bootstrap are selected, and save.'
echo 'Then return to the F-Linux project and run: sudo bash scripts/build-iso.sh'
