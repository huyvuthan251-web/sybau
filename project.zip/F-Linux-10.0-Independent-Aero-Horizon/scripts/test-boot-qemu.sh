#!/usr/bin/env bash
# Actual boot smoke test. Success requires the Live Xfce session readiness marker.
set -Eeuo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ISO="$PROJECT_DIR/dist/F-Linux-10.0-Aero-Horizon-amd64.iso"
MODE='bios'
TIMEOUT=300
RAM=6144
CPUS=4
while (($#)); do
  case "$1" in
    --iso) (($# >= 2)) || { echo '--iso requires a path' >&2; exit 2; }; ISO="$2"; shift 2 ;;
    --uefi) MODE='uefi'; shift ;;
    --bios) MODE='bios'; shift ;;
    --timeout) (($# >= 2)) || { echo '--timeout requires seconds' >&2; exit 2; }; TIMEOUT="$2"; shift 2 ;;
    --ram) (($# >= 2)) || { echo '--ram requires MiB' >&2; exit 2; }; RAM="$2"; shift 2 ;;
    --cpus) (($# >= 2)) || { echo '--cpus requires count' >&2; exit 2; }; CPUS="$2"; shift 2 ;;
    -h|--help) echo 'Usage: scripts/test-boot-qemu.sh [--iso FILE] [--bios|--uefi] [--timeout SEC] [--ram MiB] [--cpus N]'; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done
[[ "$TIMEOUT" =~ ^[0-9]+$ ]] && (( TIMEOUT >= 30 && TIMEOUT <= 1800 )) || { echo 'Timeout must be 30..1800 seconds.' >&2; exit 2; }
[[ "$RAM" =~ ^[0-9]+$ ]] && (( RAM >= 2048 )) || { echo 'RAM must be >=2048 MiB.' >&2; exit 2; }
[[ "$CPUS" =~ ^[0-9]+$ ]] && (( CPUS >= 1 && CPUS <= 64 )) || { echo 'CPUs must be 1..64.' >&2; exit 2; }
[[ -s "$ISO" ]] || { echo "ISO not found: $ISO" >&2; exit 1; }
command -v qemu-system-x86_64 >/dev/null 2>&1 || { echo 'qemu-system-x86_64 is not installed.' >&2; exit 127; }
command -v python3 >/dev/null 2>&1 || { echo 'python3 is required for QEMU monitor and screenshot capture.' >&2; exit 127; }

OUT="$PROJECT_DIR/artifacts/boot-tests/$MODE"
mkdir -p "$OUT"
SERIAL="$OUT/serial.log"
STDOUT="$OUT/qemu.stdout.log"
STDERR="$OUT/qemu.stderr.log"
# Unix-domain sockets have a short pathname limit on Linux; keep the HMP
# monitor socket in a compact /tmp directory, while preserving logs/screenshots.
MONITOR_DIR="$(mktemp -d "${TMPDIR:-/tmp}/flinux-qemu.XXXXXX")"
MONITOR="$MONITOR_DIR/m.sock"
SCREENSHOT="$OUT/desktop.ppm"
rm -f "$SERIAL" "$STDOUT" "$STDERR" "$SCREENSHOT"
# shellcheck disable=SC2054  # commas belong to the QEMU option syntax
args=(-machine q35 -cpu max -m "$RAM" -smp "$CPUS" -boot order=d -cdrom "$ISO"
      -device virtio-vga -device virtio-net-pci,netdev=net0 -netdev user,id=net0
      -display none -serial "file:$SERIAL" -monitor "unix:$MONITOR,server=on,wait=off"
      -no-reboot)
if [[ "$MODE" == uefi ]]; then
  firmware="${OVMF_CODE:-}"
  for candidate in /usr/share/OVMF/OVMF_CODE.fd /usr/share/OVMF/OVMF_CODE_4M.fd \
    /usr/share/ovmf/OVMF.fd /usr/share/edk2/x64/OVMF_CODE.4m.fd /usr/share/qemu/OVMF_CODE.fd; do
    [[ -n "$firmware" ]] && break
    [[ -r "$candidate" ]] && firmware="$candidate"
  done
  [[ -r "$firmware" ]] || { echo 'UEFI firmware not found; install ovmf or set OVMF_CODE.' >&2; exit 1; }
  args+=(-bios "$firmware")
fi
if [[ -r /dev/kvm && -w /dev/kvm ]]; then args+=(-enable-kvm); fi

"${QEMU_BIN:-qemu-system-x86_64}" "${args[@]}" >"$STDOUT" 2>"$STDERR" &
QEMU_PID=$!
cleanup() {
  if kill -0 "$QEMU_PID" 2>/dev/null; then kill "$QEMU_PID" 2>/dev/null || true; wait "$QEMU_PID" 2>/dev/null || true; fi
  rm -rf "$MONITOR_DIR"
}
trap cleanup EXIT INT TERM

ready=0
for ((second=0; second<TIMEOUT; second++)); do
  if [[ -s "$SERIAL" ]] && grep -q 'F-LINUX-DESKTOP-READY' "$SERIAL"; then ready=1; break; fi
  if ! kill -0 "$QEMU_PID" 2>/dev/null; then
    echo "[FAIL] QEMU exited before the desktop-ready marker ($MODE)." >&2
    cat "$STDERR" >&2 || true
    cat "$SERIAL" >&2 || true
    exit 1
  fi
  sleep 1
done
if (( ! ready )); then
  echo "[FAIL] Timed out after ${TIMEOUT}s waiting for the Live Xfce session ($MODE)." >&2
  cat "$SERIAL" >&2 || true
  cat "$STDERR" >&2 || true
  exit 1
fi

# Ask the HMP monitor to capture the VGA framebuffer. Keep the serial log even
# if a headless QEMU/display backend does not support screendump on this host.
python3 - "$MONITOR" "$SCREENSHOT" <<'PY'
import socket, sys, time
sock_path, output_path = sys.argv[1:]
s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
s.settimeout(5)
s.connect(sock_path)
time.sleep(0.2)
try:
    s.recv(4096)
except OSError:
    pass
s.sendall(f"screendump {output_path}\n".encode())
time.sleep(1)
try:
    s.recv(4096)
except OSError:
    pass
s.close()
PY
if [[ -s "$SCREENSHOT" ]]; then
  echo "[PASS] $MODE boot reached Xfce; screenshot: $SCREENSHOT"
else
  echo "[WARN] $MODE boot reached Xfce, but QEMU did not save a screenshot; serial log: $SERIAL" >&2
fi
printf '[PASS] %s boot reached F-LINUX-DESKTOP-READY\n' "$MODE"
# Preserve the desktop screenshot/log, then stop QEMU cleanly.
python3 - "$MONITOR" <<'PY'
import socket, sys, time
s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
s.settimeout(2)
try:
    s.connect(sys.argv[1]); s.sendall(b'quit\n'); time.sleep(0.2)
except OSError:
    pass
finally:
    s.close()
PY
wait "$QEMU_PID" 2>/dev/null || true
rm -rf "$MONITOR_DIR"
trap - EXIT INT TERM
