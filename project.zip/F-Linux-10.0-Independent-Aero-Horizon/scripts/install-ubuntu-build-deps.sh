#!/usr/bin/env bash
set -Eeuo pipefail
. /etc/os-release
if [[ "${ID:-}" != ubuntu || "${VERSION_ID:-}" != 24.04 ]]; then
  echo "This helper is written for Ubuntu 24.04; detected ${PRETTY_NAME:-unknown}." >&2
  exit 2
fi
run_apt() {
  if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
    apt-get "$@"
  else
    sudo apt-get "$@"
  fi
}
run_apt update
run_apt install -y \
  bash build-essential bison bc flex gawk git subversion curl wget rsync \
  libncurses-dev libssl-dev libelf-dev libreadline-dev pkg-config \
  perl python3 ruby m4 make patch diffutils findutils file \
  gzip bzip2 xz-utils zstd lzop cpio tar unzip zip automake autoconf libtool gettext \
  xorriso squashfs-tools grub-common grub-pc-bin grub-efi-amd64-bin mtools dosfstools \
  qemu-system-x86 ovmf shellcheck desktop-file-utils qemu-utils
printf '\nHost dependencies installed. This changes only the Ubuntu build host; F-Linux target packages are built from source by T2.\n'
