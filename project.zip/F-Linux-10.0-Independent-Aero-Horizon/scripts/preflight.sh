#!/usr/bin/env bash
set -Eeuo pipefail
fail() { echo "[FAIL] $*" >&2; exit 1; }
warn() { echo "[WARN] $*" >&2; }
pass() { echo "[PASS] $*"; }
[[ "$(uname -m)" == x86_64 ]] || fail "Build host must be x86_64; got $(uname -m)."
[[ -r /etc/os-release ]] || fail '/etc/os-release missing.'
. /etc/os-release
case "${ID:-}" in ubuntu|debian) pass "Build host: ${PRETTY_NAME:-$ID}" ;; *) warn "Untested build host: ${PRETTY_NAME:-$ID}" ;; esac
for tool in bash git make gcc g++ perl python3 rsync xz zstd; do
  command -v "$tool" >/dev/null 2>&1 || fail "Missing host tool: $tool"
done
ram_kb="$(awk '/MemTotal/ {print $2}' /proc/meminfo)"
ram_gb=$(( ram_kb / 1024 / 1024 ))
[[ "$ram_gb" -ge 8 ]] || warn "Only ${ram_gb} GiB RAM; 16 GiB is recommended for the desktop source build."
avail_kb="$(df -Pk . | awk 'NR==2 {print $4}')"
disk_gb=$(( avail_kb / 1024 / 1024 ))
[[ "$disk_gb" -ge 80 ]] || warn "Only ${disk_gb} GiB free; reserve at least 120 GiB for a full desktop source build."
[[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]] && pass 'Graphical host session present' || true
pass 'Preflight checks complete. Warnings are advisory; source builds can require more resources.'
