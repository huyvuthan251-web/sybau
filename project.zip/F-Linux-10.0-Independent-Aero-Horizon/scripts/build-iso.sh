#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
T2_DIR="${T2_DIR:-$PROJECT_DIR/t2sde}"
IMAGE_PREFIX='F-Linux-10.0-Aero-Horizon-amd64'
LOG="$PROJECT_DIR/build-iso.log"
fail() { echo "[FAIL] $*" >&2; exit 1; }

[[ ${EUID:-$(id -u)} -eq 0 ]] || fail 'T2 build requires root. Run: sudo bash scripts/build-iso.sh'
[[ -x "$T2_DIR/t2" ]] || fail "T2 checkout not found: $T2_DIR (run scripts/bootstrap-t2.sh first)."
[[ -f "$T2_DIR/target/flinux/.flinux-managed" ]] || fail 'The T2 target is not marked as installed by this F-Linux project; rerun bootstrap.'
[[ -s "$T2_DIR/config/flinux/config" ]] || fail "Missing config/flinux/config. Run: sudo '$T2_DIR/t2' config -cfg flinux"
[[ -s "$T2_DIR/config/flinux/packages" ]] || fail 'Missing config/flinux/packages. Re-run t2 config and save the configuration for target flinux.'
selected_count="$(grep -c '^X' "$T2_DIR/config/flinux/packages" || true)"
[[ "$selected_count" =~ ^[0-9]+$ ]] || fail 'Could not count selected packages in config/flinux/packages.'
(( selected_count >= 50 )) || fail "Only $selected_count packages are selected. Re-run T2 Config, save the configuration for target flinux before building."

free_gb="$(df -BG --output=avail "$T2_DIR" | tail -n 1 | tr -dc '0-9')"
[[ -n "$free_gb" ]] || fail 'Cannot determine free disk space.'
if (( free_gb < 80 )); then
  echo "WARNING: only ${free_gb} GiB free. The full desktop source build is likely to need much more; 120 GiB free is recommended." >&2
  answer=''
  read -r -p 'Continue anyway? [y/N] ' answer || true
  [[ "$answer" =~ ^[Yy]$ ]] || exit 1
fi

mkdir -p "$PROJECT_DIR/dist"
cd "$T2_DIR" || fail "Cannot enter T2 checkout: $T2_DIR"
{
  echo "F-Linux source build started: $(date -Is)"
  cat "$PROJECT_DIR/T2-LOCK.txt" 2>/dev/null || true
  echo '--- selected package count ---'
  printf '%s selected packages\n' "$selected_count"
  echo '--- download required source files ---'
  ./t2 download -cfg flinux -required
  echo '--- build target from source ---'
  ./t2 build-target -cfg flinux
  echo '--- create live ISO ---'
  ./t2 create-iso "$IMAGE_PREFIX" flinux
} 2>&1 | tee "$LOG"

shopt -s nullglob
images=("$T2_DIR/$IMAGE_PREFIX"*.iso)
((${#images[@]} > 0)) || {
  echo 'No ISO found. T2 package errors:' >&2
  ./t2 list-errors >&2 || true
  fail "T2 build did not produce $IMAGE_PREFIX*.iso; inspect $LOG and T2 package error logs."
}
for image in "${images[@]}"; do
  dest="$PROJECT_DIR/dist/$(basename "$image")"
  install -m 0644 "$image" "$dest"
  (cd "$PROJECT_DIR/dist" && sha256sum "$(basename "$dest")" > "$(basename "$dest").sha256")
  echo "ISO created: $dest"
  echo "SHA-256: $(cut -d ' ' -f1 "$dest.sha256")"
done
