#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ISO="$PROJECT_DIR/dist/F-Linux-10.0-Aero-Horizon-amd64.iso"
FIRMWARE='bios'
RAM='4096'
CPUS='4'

usage() {
  cat <<'HELP'
Usage: scripts/run-qemu.sh [ISO] [--uefi] [--ram MiB] [--cpus COUNT]
Examples:
  scripts/run-qemu.sh
  scripts/run-qemu.sh --uefi
  scripts/run-qemu.sh dist/F-Linux-10.0-Aero-Horizon-amd64.iso --ram 8192
HELP
}
if (($#)) && [[ "$1" != --* ]]; then ISO="$1"; shift; fi
while (($#)); do
  case "$1" in
    --uefi) FIRMWARE='uefi'; shift ;;
    --ram)
      (($# >= 2)) || { echo '--ram requires MiB' >&2; exit 2; }
      RAM="$2"; shift 2 ;;
    --cpus)
      (($# >= 2)) || { echo '--cpus requires a count' >&2; exit 2; }
      CPUS="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done
if [[ ! "$RAM" =~ ^[0-9]+$ ]] || (( RAM < 1024 )); then
  echo 'RAM must be an integer >= 1024 MiB.' >&2
  exit 2
fi
if [[ ! "$CPUS" =~ ^[0-9]+$ ]] || (( CPUS < 1 || CPUS > 128 )); then
  echo 'CPU count must be an integer from 1 to 128.' >&2
  exit 2
fi
[[ -s "$ISO" ]] || { echo "ISO not found: $ISO" >&2; exit 1; }
command -v qemu-system-x86_64 >/dev/null 2>&1 || { echo 'Install qemu-system-x86 first.' >&2; exit 127; }
# shellcheck disable=SC2054  # commas belong to the QEMU option syntax
args=(-m "$RAM" -smp "$CPUS" -machine q35 -cpu max -boot d -cdrom "$ISO" -device virtio-vga -device virtio-net-pci,netdev=n1 -netdev user,id=n1 -no-reboot)
if [[ "$FIRMWARE" == uefi ]]; then
  firmware="${OVMF_CODE:-}"
  if [[ -n "$firmware" && ! -r "$firmware" ]]; then
    echo "OVMF_CODE is not readable: $firmware" >&2
    exit 1
  fi
  for p in /usr/share/OVMF/OVMF_CODE.fd /usr/share/OVMF/OVMF_CODE_4M.fd /usr/share/ovmf/OVMF.fd /usr/share/edk2/x64/OVMF_CODE.4m.fd /usr/share/qemu/OVMF_CODE.fd; do
    if [[ -n "$firmware" ]]; then break; fi
    if [[ -r "$p" ]]; then firmware="$p"; break; fi
  done
  [[ -n "$firmware" ]] || { echo 'UEFI firmware not found. Install the ovmf package.' >&2; exit 1; }
  args+=(-bios "$firmware")
fi
if [[ -e /dev/kvm && -r /dev/kvm && -w /dev/kvm ]]; then args+=(-enable-kvm); fi
exec qemu-system-x86_64 "${args[@]}"
